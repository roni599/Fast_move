<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Quick Express</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
</head>

<body>

    <div class="card">
        <div class="card-body">

            <form action="<?php echo e(url('/calculator/search')); ?>" method="get">
                <?php echo csrf_field(); ?>
                <div class="input-group mb-3">
                    <div class="form-group-feedback form-group-feedback-left">
                        <input type="search" name="search" class="form-control form-control-lg" placeholder="Search by From ID or Destination">
                        
                        <div class="form-control-feedback form-control-feedback-lg">
                            <i class="icon-search4 text-muted"></i>
                        </div>
                    </div>

                    <div class="input-group-append ms-2">
                        <button type="submit" class="btn btn-primary btn-lg">Search</button>
                    </div>
                </div>

                
            </form>
        </div>
    </div>


    <?php if(Session::has('success')): ?>
        <div class="alert alert-success"><?php echo e(Session::get('success')); ?></div>
    <?php endif; ?>
    <?php if(Session::has('fail')): ?>
        <div class="alert alert-danger"><?php echo e(Session::get('fail')); ?></div>
    <?php endif; ?>

    <div style="display: flex;" class="mt-5">
        <button type="button" class="btn btn-primary" style="margin-left: 450px;"><a href="<?php echo e(route('delivery.create')); ?>" style="color: black">Add Percel (Delivery)</a></button>
    </div>

    <table class="table table-dark table-striped mt-3">
        <thead>
            <tr>
                <th scope="col">ID</th>
                <th scope="col">Type</th>
                <th scope="col">Name</th>
                <th scope="col">Phone</th>
                <th scope="col">Address</th>
                <th scope="col">Police Station</th>
                <th scope="col">District</th>
                <th scope="col">COD_Amount</th>
                <th scope="col">Invoice</th>
                <th scope="col">Note</th>
                <th scope="col">Weight</th>
                <th scope="col">Exchange Parcel</th>
                <th scope="col">Show</th>
                <th scope="col">Update</th>
                <th scope="col">Delete</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $deliveries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $delivery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($delivery->id); ?></td>
                <td><?php echo e($delivery->type); ?></td>
                <td><?php echo e($delivery->name); ?></td>
                <td><?php echo e($delivery->phone); ?></td>
                <td><?php echo e($delivery->address); ?></td>
                <td><?php echo e($delivery->ps); ?></td>
                <td><?php echo e($delivery->district); ?></td>
                <td><?php echo e($delivery->cod); ?></td>
                <td><?php echo e($delivery->invoice); ?></td>
                <td><?php echo e($delivery->note); ?></td>
                <td><?php echo e($delivery->weight); ?></td>
                <td><?php echo e($delivery->exchange); ?></td>

                <td> 
                    <a href="<?php echo e(route('delivery.show', $delivery->id)); ?>" class="btn btn-info">
                        Show
                    </a>
                </td>
                <td>
                    <a href="<?php echo e(route('delivery.edit', $delivery->id)); ?>" class="btn btn-success" style="margin-left: 10px;">
                        Update
                    </a>
                </td>
                <td>
                    <form action="<?php echo e(route('delivery.destroy', $delivery->id)); ?>" method="post"  style="margin-left: 10px;">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-danger" onclick="return confirm('Are you sure?')">Delete</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
        </tbody>
    </table>


    


    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous">
    </script>
</body>

</html>
<?php /**PATH E:\xampp\htdocs\rifat\quick-express\resources\views/server/pages/delivery-table.blade.php ENDPATH**/ ?>