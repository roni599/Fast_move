
<?php $__env->startSection('content'); ?>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css"
        integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">

    <div class="card mb-3">
        <div class="card-body">
            <nav class="navbar navbar-light bg-light">
                <form id="searchForm" action="<?php echo e(route('admin.delivery.search')); ?>" method="get">
                    <div class="input-group mb-0">
                        <div class="form-group-feedback form-group-feedback-left">
                            <input type="search" name="admin_delivery_search" class="form-control mr-sm-2"
                                placeholder="Search" id="searchInput">
                        </div>
                        <div class="input-group-append ms-2">
                            <button type="submit" class="btn btn-dark my-2 my-sm-0">Search</button>
                        </div>
                    </div>
                </form>
            </nav>
        </div>
        
    </div>
    <div class="col-lg-12 stretch-card" id="existingTable">
        <div class="card">
            <div class="card-body">
                <h4 class="card-title">Delivery Table</h4>
                <?php if(Session::has('success')): ?>
                    <div class="alert alert-success"><?php echo e(Session::get('success')); ?></div>
                <?php endif; ?>
                <?php if(Session::has('fail')): ?>
                    <div class="alert alert-danger"><?php echo e(Session::get('fail')); ?></div>
                <?php endif; ?>
                <div class="table-responsive bg-light">
                    <table class="table table-light table-hover">
                        <thead>
                            <tr>
                                <th scope="col">ID</th>
                                <th scope="col">Merchant Name</th>
                                <th scope="col">Customer Name</th>
                                <th scope="col">Customer Phone</th>
                                <th scope="col">Address</th>
                                <th scope="col">Police Station</th>
                                <th scope="col">District</th>
                                <th scope="col">Division</th>
                                <th scope="col">Product Category</th>
                                <th scope="col">Delivery Type</th>
                                <th scope="col">COD</th>
                                <th scope="col">Order Tracking Id</th>
                                <th scope="col">Invoice</th>
                                <th scope="col">Note</th>
                                <th scope="col">Exchange Status</th>
                                <th scope="col">Delivery Charge</th>
                                <th scope="col">Status</th>
                                <th scope="col">Action</th>
                                
                            </tr>
                        </thead>
                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $delivery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="table-info">
                                <td><?php echo e($delivery->id); ?></td>
                                <td><?php echo e($delivery->user->merchant_name); ?></td>
                                <td><?php echo e($delivery->customer_name); ?></td>
                                <td><?php echo e($delivery->customer_phone); ?></td>
                                <td><?php echo e($delivery->full_address); ?></td>
                                <td><?php echo e($delivery->police_station); ?></td>
                                <td><?php echo e($delivery->district); ?></td>
                                <td><?php echo e($delivery->divisions); ?></td>
                                <td><?php echo e($delivery->product_category); ?></td>
                                <td><?php echo e($delivery->delivery_type); ?></td>
                                <td><?php echo e($delivery->cod_amount); ?></td>
                                <td><?php echo e($delivery->order_tracking_id); ?></td>
                                <td><?php echo e($delivery->invoice); ?></td>
                                <td><?php echo e($delivery->note); ?></td>
                                <td><?php echo e($delivery->exchange_status); ?></td>
                                <td><?php echo e($delivery->delivery_charge); ?></td>
                                <?php if($delivery->is_active == 1): ?>
                                    <td><span class="badge bg-label-danger me-1 text-dark">Pending</span></td>
                                <?php elseif($delivery->is_active == 2): ?>
                                    <td><span class="badge bg-label-danger me-1 text-dark">On the way</span></td>
                                <?php elseif($delivery->is_active == 3): ?>
                                    <td><span class="badge bg-label-danger me-1 text-dark">Checkout</span></td>
                                <?php elseif($delivery->is_active === 'cancelled'): ?>
                                    <td><span class="badge bg-label-success me-1 text-dark">Cancelled</span></td>
                                <?php elseif($delivery->is_active == 5): ?>
                                    <td><span class="badge bg-label-success me-1 text-dark">Return</span></td>
                                <?php else: ?>
                                    <td><span class="badge bg-label-success me-1 text-dark">Delivered</span></td>
                                <?php endif; ?>

                                <td>
                                    <?php if($delivery->is_active == 3): ?>
                                        <form action="<?php echo e(route('deliveryman.product.delivered')); ?>" method="post">
                                            <?php echo csrf_field(); ?>
                                            <input type="hidden" name="id" value="<?php echo e($delivery->id); ?>">
                                            <button class="btn btn-sm btn-success" type="submit">
                                                <i class="fa-solid fa-cart-shopping"></i>
                                            </button>
                                        </form>
                                    <?php endif; ?>

                                    <?php if($delivery->is_active == 3): ?>
                                        <form action="<?php echo e(route('deliveryman.product.return')); ?>" method="post">
                                            <?php echo csrf_field(); ?>
                                            <input type="hidden" name="id" value="<?php echo e($delivery->id); ?>">
                                            <button class="btn btn-sm btn-success" type="submit">
                                                <i class="fa-solid fa-right-left"></i>
                                            </button>
                                        </form>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>

            </div>
        </div>
    </div>


    


    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous">
    </script>

    <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>

    

    


    
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('deliveryman.layouts.masterlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Rifat R Rayhan\Desktop\fast-move\resources\views/deliveryman/pages/product-table.blade.php ENDPATH**/ ?>