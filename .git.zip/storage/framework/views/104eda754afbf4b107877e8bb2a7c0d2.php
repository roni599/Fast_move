
<?php $__env->startSection('content'); ?>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css"
        integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">


    





    <div class="col-lg-12 stretch-card" id="existingTable">
        <div class="card">
            <div class="card-body">
                <h4 class="card-title">Calculate Delivery Charge Table</h4>
                <?php if(Session::has('success')): ?>
                    <div class="alert alert-success"><?php echo e(Session::get('success')); ?></div>
                <?php endif; ?>
                <?php if(Session::has('fail')): ?>
                    <div class="alert alert-danger"><?php echo e(Session::get('fail')); ?></div>
                <?php endif; ?>
                <div class="table-responsive">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th scope="col">ID</th>
                                <th scope="col">From</th>
                                <th scope="col">Destination</th>
                                <th scope="col">Category (Regular)</th>
                                <th scope="col">Category (Document)</th>
                                <th scope="col">Category (Book)</th>
                                <th scope="col">Service (Regular)</th>
                                <th scope="col">Service (Same Day)</th>
                                <th scope="col">Service (Pickup)</th>
                                <th scope="col">Service (Pickup & Drop)</th>
                                <th scope="col">Weight</th>
                                <th scope="col">Price</th>
                                <th scope="col">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $calculates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $calculate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="table-info">
                                    <td><?php echo e($calculate->id); ?></td>
                                    <td><?php echo e($calculate->from_location); ?></td>
                                    <td><?php echo e($calculate->destination); ?></td>
                                    <td><?php echo e($calculate->category_regular); ?></td>
                                    <td><?php echo e($calculate->category_document); ?></td>
                                    <td><?php echo e($calculate->category_book); ?></td>
                                    <td><?php echo e($calculate->regular); ?></td>
                                    <td><?php echo e($calculate->same_day); ?></td>
                                    <td><?php echo e($calculate->pickup); ?></td>
                                    <td><?php echo e($calculate->pickup_drop); ?></td>
                                    <td><?php echo e($calculate->weight); ?></td>
                                    <td><?php echo e($calculate->price); ?></td>

                                    <td>
                                        <div class="d-flex justify-content-center gap-2">
                                            <a href="<?php echo e(route('deliverycharge.show', $calculate->id)); ?>" class="btn btn-info">
                                                <i class="fas fa-eye"></i></a>
                                            <a href="<?php echo e(route('deliverycharge.edit', $calculate->id)); ?>" class="btn btn-success"> 
                                                <i class="fas fa-pencil-alt"></i></a>
                                                <form action="<?php echo e(route('deliverycharge.destroy', $calculate->id)); ?>" method="post">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="btn btn-sm btn-danger"
                                                    onclick="return confirm('Are you sure?')"> <i class="fas fa-trash-alt"></i>
                                                </button>
                                            </form>
                                        </div>
                                    </td>

                                    
                                </tr>


                                
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>
                    </table>
                </div>
                <?php echo e($calculates->onEachSide(1)->links()); ?>

            </div>
        </div>
    </div>





    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous">
    </script>

    <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('server.layouts.masterlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ekRoni\Desktop\fast-move\resources\views/server/pages/calculator-table.blade.php ENDPATH**/ ?>