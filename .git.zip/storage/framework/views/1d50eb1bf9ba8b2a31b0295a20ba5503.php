<div class="container-xxl py-5 bg-primary hero-header mb-5">
    <div class="container my-5 py-5 px-lg-5">
        <div class="row g-5">
            <div class="col-lg-6 pt-5 text-center text-lg-start">
                <h1 class="display-5 text-white mb-4 animated slideInLeft ">Bringing Speed to Your
                    Shipments!</h1>
                <p class="text-white animated slideInLeft">"Swift solutions, seamless service – Quick
                    Express Delivery is your express ticket to prompt and reliable deliveries!"</p>
                <a href="" class="btn btn-dark py-sm-3 px-sm-5 me-3 animated slideInLeft">Get Started
                    Now</a>
            </div>
            <div class="col-lg-6 text-center text-lg-start">
                <img class="img-fluid animated zoomIn" src="frontend/img/Delivery-Service-6.png" alt="">
            </div>
        </div>
    </div>
</div><?php /**PATH C:\Users\Farzana\Desktop\quick-express\resources\views/client/components/slider.blade.php ENDPATH**/ ?>