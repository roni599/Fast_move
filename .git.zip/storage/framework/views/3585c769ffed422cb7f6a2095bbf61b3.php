

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-9 grid-margin stretch-card">
            <div class="card">
                <div class="card-body">
                    <?php if(Session::has('success')): ?>
                        <div class="alert alert-success"><?php echo e(Session::get('success')); ?></div>
                    <?php endif; ?>
                    <?php if(Session::has('fail')): ?>
                        <div class="alert alert-danger"><?php echo e(Session::get('fail')); ?></div>
                    <?php endif; ?>
                    <div class="page-header">
                        <h3 class="page-title">
                            <span class="page-title-icon bg-gradient-primary text-white me-2">
                                <i class="mdi mdi-home"></i>
                            </span> Update Parcel Delivery
                        </h3>
                        <nav aria-label="breadcrumb">
                            <ul class="breadcrumb">
                                <li class="breadcrumb-item active" aria-current="page">
                                    <span></span>Overview <i
                                        class="mdi mdi-alert-circle-outline icon-sm text-primary align-middle"></i>
                                </li>
                            </ul>
                        </nav>
                    </div>
                    
                    <form action="<?php echo e(route('admin.delivery.update')); ?>" class="forms-sample" method="post">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="id" value="<?php echo e($delivery->id); ?>">
                        <div class="form-group row">
                            <label for="exampleInputEmail2" class="col-sm-3 col-form-label">Name</label>
                            <div class="col-sm-9">
                                <input type="text" name="name" class="form-control" id="exampleInputEmail2"
                                    value="<?php echo e($delivery->name); ?>">
                            </div>
                        </div>
                        
                        <div class="form-group row">
                            <label for="exampleInputMobile" class="col-sm-3 col-form-label">Mobile</label>
                            <div class="col-sm-9">
                                <input type="text" name="phone" class="form-control" id="exampleInputMobile"
                                value="<?php echo e($delivery->phone); ?>">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="exampleInputPassword2" class="col-sm-3 col-form-label">Address</label>
                            <div class="col-sm-9">
                                <input type="text" name="address" class="form-control" id="exampleInputPassword2"
                                    value="<?php echo e($delivery->address); ?>">

                            </div>
                        </div>
                        <div class="form-group">
                            <label for="exampleFormControlSelect2">Select Division</label>
                            <select name="divisions" class="form-control" id="divisions" onchange="divisionsList();">
                                <option selected value="<?php echo e($delivery->divisions); ?>"><?php echo e($delivery->divisions); ?></option>
                                <option value="Barishal">Barishal</option>
                                <option value="Chattogram">Chattogram</option>
                                <option value="Dhaka">Dhaka</option>
                                <option value="Khulna">Khulna</option>
                                <option value="Mymensingh">Mymensingh</option>
                                <option value="Rajshahi">Rajshahi</option>
                                <option value="Rangpur">Rangpur</option>
                                <option value="Sylhet">Sylhet</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="exampleFormControlSelect2">Select District</label>
                            <select name="district" class="form-control" id="distr" onchange="thanaList();">
                                <option selected value="<?php echo e($delivery->district); ?>"><?php echo e($delivery->district); ?></option>
                            </select>
                        </div>

                        <div class="form-group">
                            <label for="exampleFormControlSelect2">Select Police Station</label>
                            <select name="police_station" class="form-control" id="polic_sta">
                                <option selected value="<?php echo e($delivery->police_station); ?>"><?php echo e($delivery->police_station); ?></option>
                            </select>
                        </div>

                        <div class="form-group">
                            <label for="exampleFormControlSelect2">Category Type</label>
                            <select name="category_type" class="form-control" id="category">
                                <option selected value="<?php echo e($delivery->category_type); ?>"><?php echo e($delivery->category_type); ?></option>
                                <option value="Regular">Regular</option>
                                <option value="Document">Document</option>
                                <option value="Book">Book</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="exampleFormControlSelect2">Delevery Type</label>
                            <select name="delivery_type" class="form-control" id="delivery">
                                <option selected value="<?php echo e($delivery->delivery_type); ?>"><?php echo e($delivery->delivery_type); ?></option>
                                <option value="Drop">Drop</option>
                                <option value="Pickup & Drop">Pickup & Drop</option>
                            </select>
                        </div>
                        <div class="form-group row">
                            <label for="exampleInputConfirmPassword2" class="col-sm-3 col-form-label">COD Amount</label>
                            <div class="col-sm-9">
                                <input type="text" name="cod_amount" class="form-control"
                                    id="exampleInputConfirmPassword2"
                                    value="<?php echo e($delivery->cod_amount); ?>">
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="exampleInputConfirmPassword2" class="col-sm-3 col-form-label">Invoice</label>
                            <div class="col-sm-9">
                                <input type="text" name="invoice" class="form-control"
                                    id="exampleInputConfirmPassword2"
                                    value="<?php echo e($delivery->invoice); ?>">
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="exampleInputConfirmPassword2" class="col-sm-3 col-form-label">Note</label>
                            <div class="col-sm-9">
                                <input type="text" name="note" class="form-control"
                                    id="exampleInputConfirmPassword2" value="<?php echo e($delivery->note); ?>">
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="exampleInputConfirmPassword2" class="col-sm-3 col-form-label">Weight</label>
                            <div class="col-sm-9">
                                <input type="text" name="weight" class="form-control"
                                    id="exampleInputConfirmPassword2" value="<?php echo e($delivery->weight); ?>">
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="exampleFormControlSelect2">Exchange Parcel</label>
                            <select name="exchange_parcel" class="form-control" id="category">
                                <option value="<?php echo e($delivery->exchange_parcel); ?>" selected><?php echo e($delivery->exchange_parcel); ?></option>
                                <option value="Yes">Yes</option>
                                <option value="No">No</option>
                            </select>
                        </div>
                        
                        <button type="submit" class="btn btn-gradient-primary me-2">Save</button>
                        
                    </form>
                </div>
            </div>
        </div>
    </div>
    <script src="../marchant/js/address.js"></script>
<?php $__env->stopSection(); ?>








<?php echo $__env->make('server.layouts.masterlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Rifat R Rayhan\Desktop\fast-move\resources\views/server/pages/admin-delivery-edit.blade.php ENDPATH**/ ?>