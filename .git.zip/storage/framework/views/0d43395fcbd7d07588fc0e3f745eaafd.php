

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-xl-8 mx-auto col-lg-12 px-3">
            <div class="w-100 bg-white shadow-sm rounded-1 p-4 mb-3 d-flex justify-content-between">
                <div>
                    <h5 class="font-18 text-color-4 mb-0">Recent Fraud Activities </h5>
                </div>
                <div class="d-flex justify-content-between">
                    <div class="mx-2">
                        <a href="<?php echo e(route('fraud_myentries')); ?>" class="btn btn-sm text-white bg-success">My Entries</a>
                    </div>
                    <div class="mx-2">
                        <a href="<?php echo e(route('fraud_add_new')); ?>" class="btn btn-sm btn-info">Add New</a>
                    </div>
                    <div class="mx-2">
                        <a href="<?php echo e(route('fraud_check_search')); ?>"
                            class="btn btn-sm btn-warning text-black fw-normal">Check</a>
                    </div>
                </div>
            </div>
            <?php $__currentLoopData = $formattedFrauds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fraud): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="w-100 bg-white rounded-2 mb-3">
                    <div class="w-100 bg-white rounded-2 mb-3">
                        <div class="w-100 rounded-2 shadow-sm">
                            <div class="w-100 bg-white rounded-2 px-2 pt-3 pb-1 font-15">
                                <div class="px-3 -2">
                                    <p>Phone: <strong><?php echo e($fraud->formattedPhoneNumber); ?></strong></p>
                                    <p>Name: <?php echo e($fraud->disputant_name); ?></p>
                                    <p>Details:<?php echo e($fraud->details); ?></p>
                                </div>
                            </div>
                            <div class="w-100 text-end rounded-2 px-2 pb-2">
                                <span class="d-inline-block text-end font-12 fst-italic"><?php echo e(\Carbon\Carbon::parse($fraud->created_at)->timezone('Asia/Dhaka')->format('h A d M Y')); ?></span>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('marchant.layouts.masterlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ekRoni\Desktop\fast-move\resources\views/marchant/pages/fraud_check.blade.php ENDPATH**/ ?>