<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <title>Fast Move</title>

    <link rel="stylesheet" href="/marchant/assets/vendors/mdi/css/materialdesignicons.min.css">
    <link rel="stylesheet" href="/marchant/assets/vendors/css/vendor.bundle.base.css">

    <link rel="stylesheet" href="/marchant/assets/css/style.css">
    <!-- End layout styles -->
    <link href="/frontend/img/delivery-bike.png" rel="icon">
</head>

<body>



    <div class="conatiner-scroller">

        <!-- partial:partials/_navbar.html -->
        <nav class="navbar default-layout-navbar col-lg-12 col-12 p-0 fixed-top d-flex flex-row">
            <div class="text-center navbar-brand-wrapper d-flex align-items-center justify-content-center">
                <a class="navbar-brand brand-logo" href="<?php echo e(route('deliveryman.dashboard')); ?>"><img
                        src="/frontend/img/delivery-bike.png" style="width: 120px; height:50px;"  alt="logo" /></a>
                
            </div>
            <div class="navbar-menu-wrapper d-flex align-items-stretch">
                <button class="navbar-toggler navbar-toggler align-self-center" type="button" data-toggle="minimize">
                    <span class="mdi mdi-menu"></span>
                </button>
                

                <ul class="navbar-nav navbar-nav-right">
                    <li class="nav-item nav-profile dropdown">
                        <a class="nav-link dropdown-toggle" id="profileDropdown" href="#"
                            data-bs-toggle="dropdown" aria-expanded="false">
                            <div class="nav-profile-img">
                                
                                <img src="<?php echo e(asset('deliverymen/profile_images')); ?>/<?php echo e($deliveryman->profile_img); ?>" alt="image">
                                <span class="availability-status online"></span>
                            </div>
                            <div class="nav-profile-text">
                                <p class="mb-1 text-black"><?php echo e($deliveryman->deliveryman_name); ?></p>
                            </div>
                        </a>
                        <div class="dropdown-menu navbar-dropdown" aria-labelledby="profileDropdown">

                            <a class="dropdown-item text-dark" href="<?php echo e(route('deliveryman.edit')); ?>">
                                <i class="mdi mdi-account-card-details me-2 text-dark"></i> Update Profile </a>
                            <div class="dropdown-divider"></div>
                            <a class="dropdown-item text-dark" href="<?php echo e(route('deliveryman.change.password')); ?>">
                                <i class="mdi mdi-account-key me-2 text-dark"></i> Change Password </a>
                            <div class="dropdown-divider"></div>
                            <a class="dropdown-item text-dark" href="<?php echo e(route('deliveryman.delete')); ?>">
                                <i class="mdi mdi-account-key me-2 text-dark"></i> Delete Account </a>
                            
                            <div class="dropdown-divider"></div>

                            <form action="<?php echo e(route('deliveryman.logout')); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="dropdown-item text-dark"> <i
                                        class="mdi mdi-logout me-2 text-dark"></i> Signout </button>
                            </form>

                        </div>
                    </li>

                </ul>

                <button class="navbar-toggler navbar-toggler-right d-lg-none align-self-center" type="button"
                    data-toggle="offcanvas">
                    <span class="mdi mdi-menu"></span>
                </button>
            </div>
        </nav>
        <!-- partial -->

        <div class="container-fluid page-body-wrapper">



            <!-- partial:partials/_sidebar.html -->
            <nav class="sidebar sidebar-offcanvas" id="sidebar">
                <ul class="nav">
                    <li class="nav-item nav-profile">
                        <a href="#" class="nav-link">
                            <div class="nav-profile-image">
                                <img src="<?php echo e(asset('deliverymen/profile_images')); ?>/<?php echo e($deliveryman->profile_img); ?>" alt="image">
                                <span class="login-status online"></span>
                                <!--change to offline or busy as needed-->
                            </div>
                            <div class="nav-profile-text d-flex flex-column">
                                    <span class="font-weight-bold mb-2"><?php echo e($deliveryman->deliveryman_name); ?></span>
                                    <span class="text-secondary text-small">Delivery Man</span>
                            </div>
                            <i class="mdi mdi-bookmark-check text-success nav-profile-badge"></i>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('deliveryman.dashboard')); ?>">
                            <span class="menu-title">Dashboard</span>
                            <i class="mdi mdi-home menu-icon"></i>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link"href="<?php echo e(route('deliveryman.product.table')); ?>">
                            <span class="menu-title">Delivery Product</span>
                            <i class="mdi mdi-shopping menu-icon"></i>
                        </a>
                    </li>


                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('deliveryman.fraud_check')); ?>">
                            <span class="menu-title">Fraud Check</span>
                            <i class="mdi mdi-emoticon-devil menu-icon"></i>
                            
                        </a>
                    </li>

                    

                    
                    
                    
                </ul>
            </nav>
            <!-- partial -->


            <div class="main-panel">
                <div class="content-wrapper">


                    <?php if (! empty(trim($__env->yieldContent('content')))): ?>
                        <?php echo $__env->yieldContent('content'); ?>
                    <?php else: ?>
                        <h1 style="text-align: center;">Here is no deliveryman content...</h1>
                    <?php endif; ?>
                </div>
            </div>

        </div>



    </div>




    <script src="/marchant/assets/vendors/js/vendor.bundle.base.js"></script>
    <script src="/marchant/assets/vendors/chart.js/Chart.min.js"></script>
    <script src="/marchant/assets/js/jquery.cookie.js" type="text/javascript"></script>
    <script src="/marchant/assets/js/off-canvas.js"></script>
    <script src="/marchant/assets/js/hoverable-collapse.js"></script>
    <script src="/marchant/assets/js/misc.js"></script>
    <script src="/marchant/assets/js/dashboard.js"></script>
    <script src="/marchant/assets/js/todolist.js"></script>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\fast-move\resources\views/deliveryman/layouts/masterlayout.blade.php ENDPATH**/ ?>