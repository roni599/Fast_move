<div class="container-xxl domain mb-5" style="margin-top: 90px;">
    <div class="container px-lg-5">
        <div class="row justify-content-center">
            <div class="col-lg-10">
                <div class="section-title position-relative text-center mx-auto mb-4 pb-4 wow fadeInUp"
                    data-wow-delay="0.1s" style="max-width: 600px;">
                    <h1 class="mb-3 fs-5">TRACK YOUR CONSIGNMENT</h1>
                    <p class="mb-1">Now you can easily track your consignment</p>
                </div>
                <div class="position-relative w-100 my-3 wow fadeInUp" data-wow-delay="0.3s">
                    <input class="form-control bg-transparent w-100 py-3 ps-4 pe-5" type="text"
                        placeholder="Enter your Tracking ID">
                    <button type="button"
                        class="btn btn-primary py-2 px-3 position-absolute top-0 end-0 mt-2 me-2">Search</button>
                </div>
                <div class="row g-3 wow fadeInUp justify-content-center" data-wow-delay="0.5s">
                    <div class="col-lg-2 col-md-4 col-sm-4 col-6 text-center">
                        <h5 class="fw-bold text-primary mb-1">24 Hours</h5>
                        <p class="mb-0">Regular Delivery</p>
                    </div>
                    <div class="col-lg-2 col-md-4 col-sm-4 col-6 text-center">
                        <h5 class="fw-bold text-primary mb-1">24 Hours</h5>
                        <p class="mb-0">Multiple Delivery</p>
                    </div>
                    <div class="col-lg-2 col-md-4 col-sm-4 col-6 text-center">
                        <h5 class="fw-bold text-primary mb-1">5 Hours</h5>
                        <p class="mb-0">Express Delivery</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div><?php /**PATH C:\Users\Farzana\Desktop\quick-express\resources\views/client/components/track.blade.php ENDPATH**/ ?>