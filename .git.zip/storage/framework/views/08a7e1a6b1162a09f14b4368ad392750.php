
<?php $__env->startSection('content'); ?>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css"
        integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
    


    <div class="card">
        <div class="card-body">
            
            <form id="searchForm">
                <div class="input-group mb-0">
                    <div class="form-group-feedback form-group-feedback-left">
                        <input type="search" class="form-control mr-sm-2" placeholder="Search by From ID or Destination"
                            id="searchInput">
                        <div class="form-control-feedback form-control-feedback-lg">
                            <i class="icon-search4 text-muted"></i>
                        </div>
                    </div>
                    <div class="input-group-append ms-2">
                        <button type="submit" class="btn btn-primary btn-lg">Search</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
    <div class="add-btn bg-white px-5">
        <a href="<?php echo e(route('addDeliveryCharge')); ?>" class="btn btn-primary btn-sm">Add Delivery Charge</a>
    </div>
    <div class="col-lg-12 stretch-card" id="existingTable">
        <div class="card">
            <div class="card-body">
                <h4 class="card-title">Calculate Delivery Charge Table</h4>
                <?php if(Session::has('success')): ?>
                    <div class="alert alert-success"><?php echo e(Session::get('success')); ?></div>
                <?php endif; ?>
                <?php if(Session::has('fail')): ?>
                    <div class="alert alert-danger"><?php echo e(Session::get('fail')); ?></div>
                <?php endif; ?>
                <div class="table-responsive">
                    <table class="table table-bordered" id="table">
                        <thead>
                            <tr>
                                <th scope="col">ID</th>
                                <th scope="col">From</th>
                                <th scope="col">Destination</th>
                                <th scope="col">Category</th>
                                <th scope="col">Delivery Type</th>
                                <th scope="col">Delivery Cost</th>
                                <th scope="col">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $calculates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $calculate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="table-info">
                                    <td><?php echo e($calculate->id); ?></td>
                                    <td><?php echo e($calculate->from_location); ?></td>
                                    <td><?php echo e($calculate->destination); ?></td>
                                    <td><?php echo e($calculate->category); ?></td>
                                    <td><?php echo e($calculate->delivery_type); ?></td>
                                    <td><?php echo e($calculate->cost); ?></td>
                                    <td>
                                        <div class="d-flex justify-content-center gap-2">
                                            
                                            <button class="btn btn-sm btn-success showButton" data-bs-toggle="modal"
                                                data-bs-target="#showModal" data-id="<?php echo e($calculate->id); ?>"
                                                data-fromlocation="<?php echo e($calculate->from_location); ?>"
                                                data-destination="<?php echo e($calculate->from_location); ?>"
                                                data-category="<?php echo e($calculate->category); ?>"
                                                data-delivery_type="<?php echo e($calculate->delivery_type); ?>"
                                                data-cost="<?php echo e($calculate->cost); ?>" id="updateDeliveryForm">
                                                <i class="fas fa-eye"></i>
                                            </button>
                                            
                                            <button class="btn btn-sm btn-success editDeliveryChargeButton"
                                                data-bs-toggle="modal" data-bs-target="#editModal"
                                                data-chargeid="<?php echo e($calculate->id); ?>"
                                                data-chargefromlocation="<?php echo e($calculate->from_location); ?>"
                                                data-chargedestination="<?php echo e($calculate->from_location); ?>"
                                                data-chargecategory="<?php echo e($calculate->category); ?>"
                                                data-chargedeliverytype="<?php echo e($calculate->delivery_type); ?>"
                                                data-chargecost="<?php echo e($calculate->cost); ?>">
                                                <i class="fas fa-pencil-alt"></i>
                                            </button>
                                            <form id="chargeDeleteConformation"
                                                action="<?php echo e(route('deliverycharge.destroy', $calculate->id)); ?>"
                                                method="post">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="btn btn-danger btn-sm"
                                                    onclick="return confirm('Are you sure?')"> <i
                                                        class="fas fa-trash-alt"></i>
                                                </button>
                                            </form>
                                        </div>
                                    </td>

                                    
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                <?php echo e($calculates->onEachSide(1)->links()); ?>

            </div>
        </div>
    </div>

    
    <div class="modal fade" id="showModal" tabindex="-1" aria-labelledby="showModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="updateModalLabel">Update Delivery Product</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="errMsgContainer"></div>
                    <div class="card">
                        <div class="card text-center">
                            <div class="card-header">
                                Delivery Charge Details
                            </div>
                            <div class="card-body">
                                <h5 class="card-title">Delivery Charge ID : <span id="chargeid"></span></h5>
                                <h5 class="card-title">From Location : <span id="fromLocation"></span></h5>
                                <h5 class="card-title">Destination : <span id="destination"></span></h5>
                                <h5 class="card-title">Category Type : <span id="category"></span></h5>
                                <h5 class="card-title">Delivery Type : <span id="deliveryType"></span></h5>
                                <h5 class="card-title">Cost : <span id="cost"></span></h5>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-gradient-primary" data-bs-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>

    
    <div class="modal fade" id="editModal" tabindex="-1" aria-labelledby="editModalLabel" aria-hidden="true">
        <form id="editDeliveryChargeForm">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="editModalLabel">Update Delivery Product</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        
                        <div class="errMsgContainer"></div>
                        <div class="card">
                            <div class="card-body">
                                <?php if(Session::has('success')): ?>
                                    <div class="alert alert-success"><?php echo e(Session::get('success')); ?></div>
                                <?php endif; ?>
                                <?php if(Session::has('fail')): ?>
                                    <div class="alert alert-danger"><?php echo e(Session::get('fail')); ?></div>
                                <?php endif; ?>
                                <div class="page-header">
                                    <h3 class="page-title">
                                        <span class="page-title-icon bg-gradient-primary text-white me-2">
                                            <i class="mdi mdi-home"></i>
                                        </span> Update Delivery Charge
                                    </h3>
                                    <nav aria-label="breadcrumb">
                                        <ul class="breadcrumb">
                                            <li class="breadcrumb-item active" aria-current="page">
                                                <span></span>Overview <i
                                                    class="mdi mdi-alert-circle-outline icon-sm text-primary align-middle"></i>
                                            </li>
                                        </ul>
                                    </nav>
                                </div>
                                <input type="hidden" id="id">
                                <div class="form-group row">
                                    <label for="exampleInputUsername2" class="col-sm-3 col-form-label">From</label>
                                    <div class="col-sm-9">
                                        <input type="text" class="form-control" name="from_location"
                                            id="fromtoLocationto">
                                        <?php $__errorArgs = ['from_location'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <?php echo e($message); ?>

                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="exampleInputEmail2" class="col-sm-3 col-form-label">Destination</label>
                                    <div class="col-sm-9">
                                        <input type="text" class="form-control" name="destination" id="destinationto"
                                            value="" placeholder="Write The Destination Location Name">
                                        <?php $__errorArgs = ['destination'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <?php echo e($message); ?>

                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="exampleFormControlSelect2">Category</label>
                                    <select name="category" class="form-control" id="categoryto">
                                        <option value="" disabled selected></option>
                                        <option value="Regular">Regular</option>
                                        <option value="Document">Document</option>
                                        <option value="Book">Book</option>
                                    </select>
                                </div>
                                <span class="text-danger mb-3 d-block">
                                    <?php $__errorArgs = ['category'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <?php echo e($message); ?>

                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </span>

                                <div class="form-group">
                                    <label for="exampleFormControlSelect2">Delevery Type</label>
                                    <select name="delivery_type" class="form-control" id="deliveryto">
                                        <option value="" disabled selected></option>
                                        <option value="drop">Drop</option>
                                        <option value="pickup and drop">Pickup & Drop</option>
                                    </select>
                                </div>
                                <span class="text-danger mb-3 d-block">
                                    <?php $__errorArgs = ['delivery_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <?php echo e($message); ?>

                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </span>

                                <div class="form-group row">
                                    <label for="exampleInputPassword2" class="col-sm-3 col-form-label">Delivery
                                        Cost/KG</label>
                                    <div class="col-sm-9">
                                        <input type="text" class="form-control text-black" id="costto"
                                            name="cost">
                                        <?php $__errorArgs = ['cost'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <?php echo e($message); ?>

                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-gradient-primary" data-bs-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-gradient-primary editDeliveryChargeSubmit">Update
                            Delivery</button>
                    </div>
                </div>
            </div>
        </form>
    </div>



    <div class="col-lg-12 stretch-card" id="searchResultsSection" style="display: none;">
        <div class="card">
            <div class="card-body">
                <h4 class="card-title">Search Results</h4>
                <div class="table-responsive">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th scope="col">ID</th>
                                <th scope="col">From</th>
                                <th scope="col">Destination</th>
                                <th scope="col">Category</th>
                                <th scope="col">Delivery Type</th>
                                <th scope="col">Delivery Cost</th>
                                <th scope="col">Action</th>
                            </tr>
                        </thead>
                        <tbody id="searchResultsBody">
                            <!-- Use JavaScript to populate this tbody with search results -->
                        </tbody>
                    </table>
                </div>
                <!-- Pagination for search results if needed -->
                <div id="searchResultsPagination">
                    <!-- Add pagination links here -->
                </div>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous">
    </script>

    <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
    <script>
        var deliveryChargeId = <?php echo e($calculate->id); ?>;
    </script>

    

    

    
    <script>
        $(document).ready(function() {
            var searchForm = $('#searchForm');
            var searchInput = $('#searchInput');

            function submitForm() {
                var searchInputValue = searchInput.val().trim();

                if (searchInputValue === '') {
                    return;
                }

                var csrfToken = '<?php echo e(csrf_token()); ?>';
                var searchRoute = '<?php echo e(route('admin.calculatorSearch')); ?>';

                $.ajax({
                    url: searchRoute,
                    type: 'POST',
                    headers: {
                        'X-CSRF-TOKEN': csrfToken
                    },
                    data: {
                        '_token': csrfToken,
                        admin_delivery_search: searchInputValue,
                    },
                    dataType: 'html',
                    success: function(response) {
                        $('#table').html(response);
                    },
                    error: function(xhr, status, error) {
                        console.error('Error fetching search results:', error);
                    }
                });
            }
            searchInput.on('input', function() {
                submitForm();
            });
            searchForm.submit(function(e) {
                e.preventDefault();
                submitForm();
            });
        });
    </script>

    
    <script>
        $(document).ready(function() {
            $(document).on('click', '.showButton', function() {
                let up_id = $(this).data('id');
                let from_location = $(this).data('fromlocation');
                let destination = $(this).data('destination')
                let category = $(this).data('category')
                let delivery_type = $(this).data('delivery_type')
                let cost = $(this).data('cost')

                $('#chargeid').text(up_id)
                $('#fromLocation').text(from_location);
                $('#destination').text(destination);
                $('#category').text(category);
                $('#deliveryType').text(delivery_type);
                $('#cost').text(cost);
            });

            $(document).on('click', '.editDeliveryChargeButton', function() {
                let chargeid = $(this).data('chargeid');
                let chargefromlocation = $(this).data('chargefromlocation');
                let chargedestination = $(this).data('chargedestination')
                let chargecategory = $(this).data('chargecategory')
                let chargedeliverytype = $(this).data('chargedeliverytype')
                let chargecost = $(this).data('chargecost')

                $('#id').val(chargeid);
                $('#fromtoLocationto').val(chargefromlocation);
                $('#destinationto').val(chargedestination);
                $('#categoryto').val(chargecategory);
                $('#deliveryto').val(chargedeliverytype);
                $('#costto').val(chargecost);
            });

            $(document).on('click', '.editDeliveryChargeSubmit', function(e) {
                e.preventDefault();
                let up_id = $('#id').val();
                let fromtoLocationto = $('#fromtoLocationto').val();
                let destinationto = $('#destinationto').val();
                let categoryto = $('#categoryto').val();
                let deliveryto = $('#deliveryto').val();
                let costto = $('#costto').val();
                var csrfToken = '<?php echo e(csrf_token()); ?>';

                $.ajax({
                    // url: "<?php echo e(route('admin.deliverycharge.update')); ?>",
                    url: "<?php echo e(route('deliverycharge.update', ['deliverycharge' => ':up_id'])); ?>"
                        .replace(':up_id', up_id),
                    // method:'POST',
                    method: 'PUT',
                    headers: {
                        'X-CSRF-TOKEN': csrfToken
                    },
                    data: {
                        '_token': csrfToken,
                        '_method': 'PUT',
                        from_location: fromtoLocationto,
                        destination: destinationto,
                        category: categoryto,
                        delivery_type: deliveryto,
                        cost: costto
                    },
                    dataType: 'json',
                    success: function(res) {
                        if (res.status == 'success') {
                            $('#editModal').modal('hide');
                            $('#updateDeliveryForm').trigger('reset');
                            $('.modal-backdrop').remove();
                            $('#table').load(location.href + ' #table');
                        }
                    },
                    error: function(err) {
                        console.error("An error occurred:", err);
                    }
                });

            });

            $(document).on('submit', '#chargeDeleteConformation', function(event) {
                event.preventDefault();
                var formData = $(this).serialize();
                $.ajax({
                    url: $(this).attr('action'),
                    method: 'POST',
                    data: formData,
                    success: function(response) {
                        $('#table').load(location.href + ' #table')
                    },
                    error: function(xhr, status, error) {
                        console.error('Error occurred:', error);
                    }
                });
            });
        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('server.layouts.masterlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fast-move\resources\views/server/pages/calculator-table.blade.php ENDPATH**/ ?>