
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-xl-8 mx-auto col-lg-12 px-3">
            <div class="w-100 bg-white shadow-sm rounded-1 p-4 mb-3 d-flex justify-content-between">
                <div>
                    <h5 class="font-18 text-color-4 mb-0">Recent Fraud Activities </h5>
                </div>
                <div class="d-flex justify-content-between">
                    
                    
                    <div class="mx-2">
                        
                        <a href="<?php echo e(route('admin.fraud_check_search')); ?>" class="btn btn-sm btn-warning text-black fw-normal">Check</a>
                    </div>
                </div>
            </div>
            <?php $__currentLoopData = $frauds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fraud): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="w-100 bg-white rounded-2 mb-3">
                    <div class="w-100 bg-white rounded-2 mb-3">
                        <div class="w-100 rounded-2 shadow-sm">
                            <div class="w-100 bg-white rounded-2 px-2 pt-3 pb-1 font-15">
                                <?php if($fraud->pickupman): ?>
                                    <div class="px-3 -2">
                                        <p><strong>Complain ID</strong> : <?php echo e($fraud->id); ?></p>
                                        <p><strong>Name of Complaintant</strong> : <?php echo e($fraud->pickupman->pickupman_name); ?>

                                        </p>
                                        <p><strong>Complaintant Designation</strong> : Pickupman</p>
                                        <p><strong>Merchant Phone</strong> : <?php echo e($fraud->phone_number); ?></p>
                                        <p><strong>Merchant Name</strong> : <?php echo e($fraud->disputant_name); ?></p>
                                        <p><strong>Complain Details</strong> : <?php echo e($fraud->details); ?></p>
                                    </div>
                                <?php elseif($fraud->user): ?>
                                    <div class="px-3 -2">
                                        <p><strong>Complain ID</strong> : <?php echo e($fraud->id); ?></p>
                                        <p><strong>Name of Complaintant</strong> : <?php echo e($fraud->user->merchant_name); ?></p>
                                        <p><strong>Complaintant Designation</strong> : Merchant</p>
                                        <p><strong>Pickupman Phone</strong> : <?php echo e($fraud->phone_number); ?></p>
                                        <p><strong>pickupman Name</strong> : <?php echo e($fraud->disputant_name); ?></p>
                                        <p><strong>Complain Details</strong> : <?php echo e($fraud->details); ?></p>
                                    </div>
                                <?php elseif($fraud->deliveryman): ?>
                                    <div class="px-3 -2">
                                        <p><strong>Complain ID</strong> : <?php echo e($fraud->id); ?></p>
                                        <p><strong>Name of Complaintant</strong> : <?php echo e($fraud->deliveryman->deliveryman_name); ?></p>
                                        <p><strong>Complaintant Designation</strong> : Deliveryman</p>
                                        <p><strong>Customer Phone</strong> : <?php echo e($fraud->phone_number); ?></p>
                                        <p><strong>Customer Name</strong> : <?php echo e($fraud->disputant_name); ?></p>
                                        <p><strong>Complain Details</strong> : <?php echo e($fraud->details); ?></p>
                                    </div>
                                <?php endif; ?>
                            </div>
                            <div class="w-100 text-end rounded-2 px-2 pb-2">
                                
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('server.layouts.masterlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fast-move\resources\views/server/pages/fraud_check.blade.php ENDPATH**/ ?>