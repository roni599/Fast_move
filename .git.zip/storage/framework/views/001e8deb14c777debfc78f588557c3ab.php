
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-9 grid-margin stretch-card">
        <div class="card">
            <div class="card-body">
                <?php if(Session::has('success')): ?>
            <div class="alert alert-success"><?php echo e(Session::get('success')); ?></div>
            <?php endif; ?>
            <?php if(Session::has('fail')): ?>
                <div class="alert alert-danger"><?php echo e(Session::get('fail')); ?></div>
            <?php endif; ?>
                <div class="page-header">
                    <h3 class="page-title">
                        <span class="page-title-icon bg-gradient-primary text-white me-2">
                            <i class="mdi mdi-home"></i>
                        </span> Update Pickupman
                    </h3>
                    <nav aria-label="breadcrumb">
                        <ul class="breadcrumb">
                            <li class="breadcrumb-item active" aria-current="page">
                                <span></span>Overview <i class="mdi mdi-alert-circle-outline icon-sm text-primary align-middle"></i>
                            </li>
                        </ul>
                    </nav>
                </div>
                
                <form action="<?php echo e(route('pickupman.update')); ?>" class="forms-sample" method="post" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="id" value="<?php echo e($pickupman->id); ?>">
                    <div class="form-group row">
                        <label for="exampleInputUsername2" class="col-sm-3 col-form-label">Pickupman Name</label>
                        <div class="col-sm-9">
                            <input type="text" class="form-control" id="exampleInputEmail2" name="pickupman_name" value="<?php echo e($pickupman->pickupman_name); ?>">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="exampleInputEmail2" class="col-sm-3 col-form-label">Phone No.</label>
                        <div class="col-sm-9">
                            <input type="text" class="form-control" id="exampleInputMobile" name="phone" value="<?php echo e($pickupman->phone); ?>">

                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="exampleInputMobile" class="col-sm-3 col-form-label">Alternative Phone No.</label>
                        <div class="col-sm-9">
                            <input type="text" class="form-control" id="exampleInputPassword2" name="alt_phone" value="<?php echo e($pickupman->alt_phone); ?>">

                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="exampleInputPassword2" class="col-sm-3 col-form-label">Email</label>
                        <div class="col-sm-9">
                            <input type="text" class="form-control" name="email" value="<?php echo e($pickupman->email); ?>">

                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="exampleInputPassword2" class="col-sm-3 col-form-label">Full Address</label>
                        <div class="col-sm-9">
                            <input type="text" class="form-control" name="full_address" value="<?php echo e($pickupman->full_address); ?>">

                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="exampleInputPassword2" class="col-sm-3 col-form-label">Division</label>
                        <div class="col-sm-9">
                            <input type="text" class="form-control" name="division" value="<?php echo e($pickupman->division); ?>">
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="exampleInputPassword2" class="col-sm-3 col-form-label">District</label>
                        <div class="col-sm-9">
                            <input type="text" class="form-control" name="district" value="<?php echo e($pickupman->district); ?>">

                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="exampleInputPassword2" class="col-sm-3 col-form-label">Police Station</label>
                        <div class="col-sm-9">
                            <input type="text" class="form-control" name="police_station" value="<?php echo e($pickupman->police_station); ?>">

                        </div>
                    </div>

                    <div class="row g-2">
                        <div class="col mb-0">
                            <label for="emailWithTitle" class="form-label">Profile Photo</label>
                            <input name="profile_img" type="file" class="file-input">
                            <img src="<?php echo e(asset('pickupmen/profile_images')); ?>/<?php echo e($pickupman->profile_img); ?>" style="width:100px;height:100px">
                            <input name="oldimage" type="hidden" class="form-control" value="<?php echo e($pickupman->profile_img); ?>">
                        </div>
                    </div>

                    <div class="row g-2">
                        <div class="col mb-0">
                            <label for="emailWithTitle" class="form-label">NID Front</label>
                            <input name="nid_front" type="file" class="file-input">
                            <img src="<?php echo e(asset('pickupmen/nid_images')); ?>/<?php echo e($pickupman->nid_front); ?>" style="width:100px;height:100px">
                            <input name="oldimage" type="hidden" class="form-control" value="<?php echo e($pickupman->nid_front); ?>">
                        </div>
                    </div>

                    <div class="row g-2">
                        <div class="col mb-0">
                            <label for="emailWithTitle" class="form-label">NID Back</label>
                            <input name="nid_back" type="file" class="file-input">
                            <img src="<?php echo e(asset('pickupmen/nid_images')); ?>/<?php echo e($pickupman->nid_back); ?>" style="width:100px;height:100px">
                            <input name="oldimage" type="hidden" class="form-control" value="<?php echo e($pickupman->nid_back); ?>">
                        </div>
                    </div>

                    <button type="submit" class="btn btn-gradient-primary me-2">Save Change</button>
                    
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('pickupman.layouts.masterlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Rifat R Rayhan\Desktop\fast-move\resources\views/pickupman/auth/pickupman-update.blade.php ENDPATH**/ ?>