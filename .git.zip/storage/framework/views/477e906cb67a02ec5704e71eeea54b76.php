

<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-md-9 grid-margin stretch-card">
        <div class="card">
            <div class="card-body">
                <?php if(Session::has('success')): ?>
            <div class="alert alert-success"><?php echo e(Session::get('success')); ?></div>
            <?php endif; ?>
            <?php if(Session::has('fail')): ?>
                <div class="alert alert-danger"><?php echo e(Session::get('fail')); ?></div>
            <?php endif; ?>
                <div class="page-header">
                    <h3 class="page-title">
                        <span class="page-title-icon bg-gradient-primary text-white me-2">
                            <i class="mdi mdi-home"></i>
                        </span> Update Delivery Charge
                    </h3>
                    <nav aria-label="breadcrumb">
                        <ul class="breadcrumb">
                            <li class="breadcrumb-item active" aria-current="page">
                                <span></span>Overview <i class="mdi mdi-alert-circle-outline icon-sm text-primary align-middle"></i>
                            </li>
                        </ul>
                    </nav>
                </div>
                <form action="<?php echo e(route('deliverycharge.update', $deliverycharge->id)); ?>" class="forms-sample" method="post">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <div class="form-group row">
                        <label for="exampleInputUsername2" class="col-sm-3 col-form-label">From</label>
                        <div class="col-sm-9">
                            <input type="text" name="from_location" value="<?php echo e($deliverycharge->from_location); ?>" class="form-control" id="exampleInputEmail2" value="<?php echo e(old('from')); ?>">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="exampleInputEmail2" class="col-sm-3 col-form-label">Destination</label>
                        <div class="col-sm-9">
                            <input type="text" class="form-control" id="exampleInputMobile" name="destination" value="<?php echo e($deliverycharge->destination); ?>">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="exampleInputMobile" class="col-sm-3 col-form-label">Category</label>
                        <div class="col-sm-9">
                            <input type="text" class="form-control" id="exampleInputPassword2" name="category" value="<?php echo e($deliverycharge->category); ?>">

                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="exampleInputPassword2" class="col-sm-3 col-form-label">Regular</label>
                        <div class="col-sm-9">
                            <input type="text" class="form-control" name="regular" value="<?php echo e($deliverycharge->regular); ?>">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="exampleInputPassword2" class="col-sm-3 col-form-label">Same Day</label>
                        <div class="col-sm-9">
                            <input type="text" class="form-control" name="same_day" value="<?php echo e($deliverycharge->same_day); ?>">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="exampleInputPassword2" class="col-sm-3 col-form-label">Pickup</label>
                        <div class="col-sm-9">
                            <input type="text" class="form-control" name="pickup" value="<?php echo e($deliverycharge->pickup); ?>">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="exampleInputPassword2" class="col-sm-3 col-form-label">Pickup & Drop</label>
                        <div class="col-sm-9">
                            <input type="text" class="form-control" name="pickup_drop" value="<?php echo e($deliverycharge->pickup_drop); ?>">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="exampleInputConfirmPassword2" class="col-sm-3 col-form-label">Weight</label>
                        <div class="col-sm-9">
                            <input type="text" class="form-control" name="weight" value="<?php echo e($deliverycharge->weight); ?>">
                    </div>

                    <div class="form-group row">
                        <label for="exampleInputConfirmPassword2" class="col-sm-3 col-form-label">Price</label>
                        <div class="col-sm-9">
                            <input type="text" class="form-control" name="price" value="<?php echo e($deliverycharge->price); ?>">
                        </div>
                    </div>

                    <div class="d-flex">
                        <button type="submit" class="btn btn-gradient-primary me-2">Update</button>
                    <button class="btn btn-gradient-primary me-2 "><a href="<?php echo e(route('deliverycharge.index')); ?>" class="text-decoration-none text-white">Cancel</a></button>
                    </div>
                    
                    
                </form>
            </div>
        </div>
    </div>
</div>








<?php $__env->stopSection(); ?>
<?php echo $__env->make('server.layouts.masterlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\rifat\fast-move\resources\views/server/pages/calculator-edit.blade.php ENDPATH**/ ?>