
<?php $__env->startSection('content'); ?>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css"
        integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
    

    <div class="card">
        <div class="card-body">
            <nav class="navbar">
                <form id="searchForm">
                    <div class="input-group mb-0">
                        <div class="form-group-feedback form-group-feedback-left">
                            <input type="search" name="admin_delivery_search" class="form-control mr-sm-2"
                                placeholder="Search" id="searchInput">
                        </div>
                        <div class="input-group-append ms-2">
                            <button type="submit" class="btn btn-primary my-2 my-sm-0">Search</button>
                        </div>
                    </div>
                </form>

                

                <a href="<?php echo e(route('admin.deliveryman.excel.export')); ?>" class="btn btn-dark my-2 my-sm-0">Export Excel</a>
            </nav>
        </div>
        
    </div>

    <div class="col-lg-12 stretch-card" id="existingTable">
        <div class="card">
            <div class="card-body">
                <h4 class="card-title">Delivery Man Table</h4>
                <?php if(Session::has('success')): ?>
                    <div class="alert alert-success"><?php echo e(Session::get('success')); ?></div>
                <?php endif; ?>
                <?php if(Session::has('fail')): ?>
                    <div class="alert alert-danger"><?php echo e(Session::get('fail')); ?></div>
                <?php endif; ?>
                <div class="table-responsive">
                    <table class="table table-bordered" id="table">
                        <thead>
                            <tr>
                                <th scope="col">ID</th>
                                <th scope="col">Delivery Man Name</th>
                                <th scope="col">Phone</th>
                                <th scope="col">Alt Phone</th>
                                <th scope="col">Email</th>
                                <th scope="col">Full Address</th>
                                <th scope="col">Police Station</th>
                                <th scope="col">District</th>
                                <th scope="col">Division</th>
                                <th scope="col">Profile Photo</th>
                                <th scope="col">NID Front</th>
                                <th scope="col">NID Back</th>
                                <th scope="col">Status</th>
                                <th scope="col">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $deliverymen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $deliveryman): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="table-info">
                                    <td><?php echo e($deliveryman->id); ?></td>
                                    <td><?php echo e($deliveryman->deliveryman_name); ?></td>
                                    <td><?php echo e($deliveryman->phone); ?></td>
                                    <td><?php echo e($deliveryman->alt_phone); ?></td>
                                    <td><?php echo e($deliveryman->email); ?></td>
                                    <td><?php echo e($deliveryman->full_address); ?></td>
                                    <td><?php echo e($deliveryman->police_station); ?></td>
                                    <td><?php echo e($deliveryman->district); ?></td>
                                    <td><?php echo e($deliveryman->division); ?></td>
                                    <td><img src="<?php echo e(asset('deliverymen/profile_images')); ?>/<?php echo e($deliveryman->profile_img); ?>"
                                            alt="Profile photo"></td>
                                    <td><img src="<?php echo e(asset('deliverymen/nid_images')); ?>/<?php echo e($deliveryman->nid_front); ?>"
                                            alt="NID Front"></td>
                                    <td><img src="<?php echo e(asset('deliverymen/nid_images')); ?>/<?php echo e($deliveryman->nid_back); ?>"
                                            alt="NID Back"></td>

                                    <?php if($deliveryman->is_active == 1): ?>
                                        <td><span class="badge bg-label-danger me-1 text-black">Pending</span></td>
                                    <?php elseif($deliveryman->is_active == 3): ?>
                                        <td><span class="badge bg-label-danger me-1 text-black">Cancelled</span></td>
                                    <?php else: ?>
                                        <td><span class="badge bg-label-success me-1 text-black">Confirmed</span></td>
                                    <?php endif; ?>


                                    <td>
                                        <div class="d-flex justify-content-center gap-2">
                                            <?php if($deliveryman->is_active == 1): ?>
                                                <form id="deliverymanConformation"
                                                    action="<?php echo e(route('admin.deliveryman_confirmation')); ?>" method="post">
                                                    <?php echo csrf_field(); ?>
                                                    <input type="hidden" name="id" value="<?php echo e($deliveryman->id); ?>">
                                                    <button class="btn btn-sm btn-success" type="submit"><i
                                                            class="fa-solid fa-check"></i></button>
                                                </form>
                                                <form id="deliverymanCancelConformation"
                                                    action="<?php echo e(route('admin.deliveryman_cancel_confirmation')); ?>"
                                                    method="post">
                                                    <?php echo csrf_field(); ?>
                                                    <input type="hidden" name="id" value="<?php echo e($deliveryman->id); ?>">
                                                    <button class="btn btn-sm btn-danger" type="submit">
                                                        <i class="fa-solid fa-times"></i>
                                                    </button>

                                                </form>
                                            <?php endif; ?>
                                            
                                            
                                            <form id="deliverymanDeleteConformation"
                                                action="<?php echo e(route('admin.deliveryman_destroy')); ?>" method="get">
                                                <?php echo csrf_field(); ?>
                                                <input type="hidden" name="id" value="<?php echo e($deliveryman->id); ?>">
                                                <button class="btn btn-sm btn-danger" type="submit"
                                                    onclick="return confirm('Are you sure?')">
                                                    <i class="far fa-trash-alt"></i>
                                                </button>
                                            </form>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>
                    </table>
                </div>
                <?php echo e($deliverymen->onEachSide(1)->links()); ?>

            </div>
        </div>
    </div>


    <div class="col-lg-12 stretch-card" id="searchResultsSection" style="display: none;">
        <div class="card">
            <div class="card-body">
                <h4 class="card-title">Search Results</h4>
                <div class="table-responsive">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th scope="col">ID</th>
                                <th scope="col"> DeliveryMan Name</th>
                                <th scope="col">Phone</th>
                                <th scope="col">Alt Phone</th>
                                <th scope="col">Email</th>
                                <th scope="col">Full Address</th>
                                <th scope="col">Police Station</th>
                                <th scope="col">District</th>
                                <th scope="col">Division</th>
                                <th scope="col">Profile Photo</th>
                                <th scope="col">NID Front</th>
                                <th scope="col">NID Back</th>
                                <th scope="col">Status</th>
                                <th scope="col">Action</th>
                            </tr>
                        </thead>
                        <tbody id="searchResultsBody">
                            <!-- Use JavaScript to populate this tbody with search results -->
                        </tbody>
                    </table>
                </div>
                <!-- Pagination for search results if needed -->
                <div id="searchResultsPagination">
                    <!-- Add pagination links here -->
                </div>
            </div>
        </div>
    </div>



    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous">
    </script>
    <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>

    
    


    
    <script>
        $(document).ready(function() {
            var searchForm = $('#searchForm');
            var searchInput = $('#searchInput');

            function submitForm() {
                var searchInputValue = searchInput.val().trim();

                if (searchInputValue === '') {
                    $('#table').load(location.href + ' #table');
                    return;
                }

                $.ajax({
                    url: '<?php echo e(route('admin.searchDeliveryman')); ?>',
                    type: 'POST',
                    data: {
                        '_token': '<?php echo e(csrf_token()); ?>',
                        admin_delivery_search: searchInputValue,
                    },
                    dataType: 'html',
                    success: function(response) {
                        $('#table').html(response);
                    },
                    error: function(xhr, status, error) {
                        console.error('Error fetching search results:', error);
                        $('#table').load(location.href + ' #table');
                    }
                });
            }
            searchInput.on('input', function() {
                submitForm();
            });
            searchForm.submit(function(e) {
                e.preventDefault();
                submitForm();
            });
        });
    </script>

    
    

    <script>
        $(document).ready(function() {
            $(document).on('submit', '#deliverymanDeleteConformation', function(event) {
                event.preventDefault();
                var formData = $(this).serialize();
                $.ajax({
                    url: $(this).attr('action'),
                    method: 'GET',
                    data: formData,
                    success: function(response) {
                        if (response.status === 'success') {
                            $('#existingTable').load(location.href + ' #existingTable > *');
                        } else {
                            console.error('Error occurred during delete operation');
                        }
                    },
                    error: function(xhr, status, error) {
                        console.error('Error occurred:', error);
                    }
                });
            });

            $(document).on('submit', '#deliverymanCancelConformation', function(event) {
                event.preventDefault();
                var formData = $(this).serialize();
                $.ajax({
                    url: $(this).attr('action'),
                    method: 'POST',
                    data: formData,
                    success: function(response) {
                        if (response.status === 'success') {
                            $('#existingTable').load(location.href + ' #existingTable > *');
                        } else {
                            console.error('Error occurred during delete operation');
                        }
                    },
                    error: function(xhr, status, error) {
                        console.error('Error occurred:', error);
                    }
                });
            });

            $(document).on('submit', '#deliverymanConformation', function(event) {
                event.preventDefault();
                var formData = $(this).serialize();
                $.ajax({
                    url: $(this).attr('action'),
                    method: 'POST',
                    data: formData,
                    success: function(response) {
                        if (response.status === 'success') {
                            $('#existingTable').load(location.href +
                                ' #existingTable > *');
                        } else {
                            console.error('Error occurred during delete operation');
                        }
                    },
                    error: function(xhr, status, error) {
                        console.error('Error occurred:', error);
                    }
                });
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('server.layouts.masterlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fast-move\resources\views/server/pages/deliveryman-table.blade.php ENDPATH**/ ?>