
<?php $__env->startSection('content'); ?>
    
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet"
integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">








<div class="col-lg-12 stretch-card">
<div class="card">
    <div class="card-body">
        <h4 class="card-title">Marchant's Table</h4>
        
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th scope="col">ID</th>
                    <th scope="col">Business Name</th>
                    <th scope="col">First Name</th>
                    <th scope="col">Last Name</th>
                    <th scope="col">Phone</th>
                    <th scope="col">Email</th>
                    <th scope="col">Pick Up Location</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="table-info">
                        <td><?php echo e($user->id); ?></td>
                        <td><?php echo e($user->business_name); ?></td>
                        <td><?php echo e($user->fname); ?></td>
                        <td><?php echo e($user->lname); ?></td>
                        <td>0<?php echo e($user->phone); ?></td>
                        <td><?php echo e($user->email); ?></td>
                        <td><?php echo e($user->pick_up_location); ?></td>

                        
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </tbody>
        </table>
        <?php echo e($users->onEachSide(1)->links()); ?>

    </div>
</div>
</div>











<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"
integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous">
</script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('server.layouts.masterlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Rifat R Rayhan\Desktop\first-move\resources\views/server/pages/marchant-table.blade.php ENDPATH**/ ?>