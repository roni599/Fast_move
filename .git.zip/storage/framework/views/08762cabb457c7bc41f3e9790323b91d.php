

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-xl-8 mx-auto col-lg-12 px-3">
            <div class="w-100 bg-white shadow-sm rounded-1 p-4 mb-3 d-flex justify-content-between">
                <div>
                    <h5 class="font-18 text-color-4 mb-0">Fraud Entries By Me </h5>
                </div>
                <div class="d-flex justify-content-between">
                    <div class="mx-2">
                        <a href="<?php echo e(route('fraud_check')); ?>" class="btn btn-sm text-white bg-success">View All</a>
                    </div>
                    <div class="mx-2">
                        <a href="<?php echo e(route('fraud_add_new')); ?>" class="btn btn-sm btn-info">Add New</a>
                    </div>
                    <div class="mx-2">
                        <a href="<?php echo e(route('fraud_check_search')); ?>"
                            class="btn btn-sm btn-warning text-black fw-normal">Check</a>
                    </div>
                </div>
            </div>
            <?php $__currentLoopData = $formattedFrauds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fraud): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="w-100 bg-white rounded-2 mb-3">
                    <div class="w-100 bg-white rounded-2 mb-3">
                        <div class="w-100 rounded-2 shadow-sm">
                            <div class="w-100 bg-white rounded-2 px-2 pt-3 pb-1 font-15">
                                <div class="px-3 -2">
                                    <p>Phone: <strong><?php echo e($fraud->formattedPhoneNumber); ?></strong></p>
                                    <p>Name: <?php echo e($fraud->disputant_name); ?></p>
                                    <p>Details:<?php echo e($fraud->details); ?></p>
                                </div>
                            </div>
                            <div class="d-flex justify-content-end mb-2">
                                <form method="POST" action="<?php echo e(route('fraud_delete', $fraud->id)); ?>" >
                                    <?php echo method_field('DELETE'); ?>
                                    <?php echo csrf_field(); ?>
                                    <button type="submit" class="btn btn-danger btn-sm me-3">Remove</button>
                                </form>
                            </div>

                            <div class="w-100 text-end rounded-2 px-2 pb-2">
                                <span
                                    class="d-inline-block text-end font-12 fst-italic me-2"><?php echo e(\Carbon\Carbon::parse($fraud->created_at)->timezone('Asia/Dhaka')->format('h A d M Y')); ?></span>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('marchant.layouts.masterlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fast-move\resources\views/marchant/pages/myentries.blade.php ENDPATH**/ ?>