@extends('server.layouts.masterlayout')
@section('content')

@endsection