@extends('deliveryman.layouts.masterlayout')
@section('content')

@endsection