@extends('marchant.layouts.masterlayout')
@section('content')
    @include('marchant.components.card')
@endsection